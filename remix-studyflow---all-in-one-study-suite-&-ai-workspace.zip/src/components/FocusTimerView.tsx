import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  Maximize2,
  Minimize2,
  Volume2,
  VolumeX,
  Radio,
  CloudRain,
  Waves,
  Coffee,
  CheckCircle2,
  Flame,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { audioSynth } from '../services/audioSynth';
import { StudyTask } from '../types';

interface FocusTimerViewProps {
  tasks: StudyTask[];
  onTaskCompletedPomodoro: (taskId: string) => void;
  onRecordStudyTime: (minutes: number) => void;
  // Shared timer state
  mode: 'work' | 'short_break' | 'long_break';
  setMode: (m: 'work' | 'short_break' | 'long_break') => void;
  timeLeft: number;
  setTimeLeft: React.Dispatch<React.SetStateAction<number>>;
  isRunning: boolean;
  setIsRunning: (running: boolean) => void;
  selectedTaskId: string;
  setSelectedTaskId: (id: string) => void;
}

export const FocusTimerView: React.FC<FocusTimerViewProps> = ({
  tasks,
  onTaskCompletedPomodoro,
  onRecordStudyTime,
  mode,
  setMode,
  timeLeft,
  setTimeLeft,
  isRunning,
  setIsRunning,
  selectedTaskId,
  setSelectedTaskId,
}) => {
  const [isZenMode, setIsZenMode] = useState(false);
  const [quoteIndex, setQuoteIndex] = useState(0);

  const FOCUS_DURATIONS = {
    work: 25 * 60,
    short_break: 5 * 60,
    long_break: 15 * 60,
  };

  const quotes = [
    '“The secret of getting ahead is getting started.” — Mark Twain',
    '“Effortful recall strengthens memory traces in the brain.” — Cognitive Science',
    '“Focus is a muscle: the more you practice it without distraction, the stronger it grows.”',
    '“You do not rise to the level of your goals. You fall to the level of your systems.” — James Clear',
    '“One single focused hour beats four distracted hours every single time.”',
  ];

  useEffect(() => {
    const quoteInterval = setInterval(() => {
      setQuoteIndex((prev) => (prev + 1) % quotes.length);
    }, 25000);
    return () => clearInterval(quoteInterval);
  }, []);

  const totalDuration = FOCUS_DURATIONS[mode];
  const progressPercent = ((totalDuration - timeLeft) / totalDuration) * 100;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  const handleModeSwitch = (newMode: 'work' | 'short_break' | 'long_break') => {
    setMode(newMode);
    setIsRunning(false);
    setTimeLeft(FOCUS_DURATIONS[newMode]);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(FOCUS_DURATIONS[mode]);
  };

  const handleSkip = () => {
    setIsRunning(false);
    if (mode === 'work') {
      handleModeSwitch('short_break');
    } else {
      handleModeSwitch('work');
    }
  };

  const currentSound = audioSynth.getCurrentTrack();

  const handleSoundToggle = (track: 'alpha' | 'rain' | 'brownnoise' | 'cafe') => {
    if (currentSound === track) {
      audioSynth.stopAmbient();
    } else {
      audioSynth.playAmbient(track);
    }
  };

  // SVGs for circle
  const radius = 130;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div
      className={`transition-all duration-300 ${
        isZenMode
          ? 'fixed inset-0 z-50 bg-slate-950 flex flex-col items-center justify-between p-4 sm:p-8'
          : 'p-3 sm:p-6 md:p-8 max-w-4xl mx-auto space-y-5 sm:space-y-8 animate-in fade-in duration-300 overflow-x-hidden'
      }`}
    >
      {/* Top Bar / Zen Header */}
      <div className="w-full flex items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span
              className={`text-[10px] sm:text-xs font-bold uppercase tracking-wider px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full ${
                mode === 'work'
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
              }`}
            >
              {mode === 'work' ? 'Deep Work Block' : 'Recovery & Rest'}
            </span>
            {isRunning && (
              <span className="flex items-center gap-1.5 text-xs text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                In Session
              </span>
            )}
          </div>
          <h2 className="text-lg sm:text-xl md:text-2xl font-black text-white mt-1 truncate">
            Pomodoro Focus Studio
          </h2>
        </div>

        <button
          onClick={() => setIsZenMode(!isZenMode)}
          className="flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 sm:py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition border border-slate-700 shrink-0"
        >
          {isZenMode ? (
            <>
              <Minimize2 className="w-3.5 h-3.5" />
              <span>Exit Zen</span>
            </>
          ) : (
            <>
              <Maximize2 className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">Zen Fullscreen</span>
            </>
          )}
        </button>
      </div>

      {/* Mode Selectors */}
      <div className="flex items-center justify-center gap-1 sm:gap-2 p-1.5 rounded-2xl bg-slate-900/80 border border-slate-800 max-w-md mx-auto w-full">
        <button
          onClick={() => handleModeSwitch('work')}
          className={`flex-1 py-1.5 sm:py-2 px-2 sm:px-4 rounded-xl text-[11px] sm:text-xs font-bold transition text-center ${
            mode === 'work'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Work (25m)
        </button>
        <button
          onClick={() => handleModeSwitch('short_break')}
          className={`flex-1 py-1.5 sm:py-2 px-2 sm:px-4 rounded-xl text-[11px] sm:text-xs font-bold transition text-center ${
            mode === 'short_break'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Short (5m)
        </button>
        <button
          onClick={() => handleModeSwitch('long_break')}
          className={`flex-1 py-1.5 sm:py-2 px-2 sm:px-4 rounded-xl text-[11px] sm:text-xs font-bold transition text-center ${
            mode === 'long_break'
              ? 'bg-teal-600 text-white shadow-md shadow-teal-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Long (15m)
        </button>
      </div>

      {/* Circular Progress & Clock Face */}
      <div className="flex flex-col items-center justify-center my-2 sm:my-4">
        <div className="relative w-60 h-60 sm:w-72 sm:h-72 md:w-80 md:h-80 flex items-center justify-center max-w-full">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 300 300">
            {/* Background Track */}
            <circle
              cx="150"
              cy="150"
              r={radius}
              stroke="#1e293b"
              strokeWidth="12"
              fill="transparent"
            />
            {/* Animated Progress Ring */}
            <circle
              cx="150"
              cy="150"
              r={radius}
              stroke={mode === 'work' ? '#6366f1' : '#10b981'}
              strokeWidth="12"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
              className="transition-all duration-1000 ease-linear"
            />
          </svg>

          {/* Central Digits & Status */}
          <div className="absolute flex flex-col items-center justify-center text-center">
            <span className="text-5xl sm:text-6xl md:text-7xl font-black text-white tracking-tighter tabular-nums font-mono drop-shadow-md">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
            <span className="text-[10px] sm:text-xs font-semibold text-slate-400 uppercase tracking-widest mt-1 sm:mt-2">
              {mode === 'work' ? 'Deep Focus' : 'Recovery Rest'}
            </span>

            {/* Selected Task Pill */}
            {selectedTaskId && (
              <div className="mt-2 sm:mt-3 max-w-[180px] sm:max-w-[200px] truncate text-[11px] sm:text-xs px-2.5 py-0.5 sm:py-1 rounded-full bg-slate-800/80 text-slate-300 border border-slate-700/60">
                {tasks.find((t) => t.id === selectedTaskId)?.title || 'Target Task'}
              </div>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3 sm:gap-4 mt-6 sm:mt-8">
          <button
            onClick={handleReset}
            title="Reset timer"
            className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition border border-slate-700/60 active:scale-95"
          >
            <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`w-16 h-16 sm:w-20 sm:h-20 rounded-3xl flex items-center justify-center text-white shadow-2xl transition transform hover:scale-105 active:scale-95 ${
              isRunning
                ? 'bg-amber-600 hover:bg-amber-500 shadow-amber-600/30'
                : mode === 'work'
                ? 'bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-500 hover:from-indigo-500 hover:to-sky-400 shadow-indigo-600/40'
                : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/40'
            }`}
          >
            {isRunning ? (
              <Pause className="w-7 h-7 sm:w-8 sm:h-8 fill-white" />
            ) : (
              <Play className="w-7 h-7 sm:w-8 sm:h-8 fill-white ml-1" />
            )}
          </button>

          <button
            onClick={handleSkip}
            title="Skip to next session"
            className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition border border-slate-700/60 active:scale-95"
          >
            <SkipForward className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>

      {/* Task Link & Ambient Sound Quick Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto w-full">
        {/* Task Link Selector */}
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
            Link Focus to Task
          </label>
          <select
            value={selectedTaskId}
            onChange={(e) => setSelectedTaskId(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-200 rounded-xl px-3 py-2.5 focus:outline-none focus:border-indigo-500"
          >
            <option value="">No specific task (General Study)</option>
            {tasks
              .filter((t) => t.status !== 'done')
              .map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title} ({t.completedPomodoros}/{t.estPomodoros} 🍅)
                </option>
              ))}
          </select>
        </div>

        {/* Ambient Study Sound Quick Switch */}
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Ambient Audio
            </span>
            {currentSound && (
              <span className="text-[10px] text-sky-400 font-bold uppercase animate-pulse">
                {currentSound}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5">
            {[
              { id: 'alpha' as const, label: 'Alpha 10Hz', icon: Radio },
              { id: 'rain' as const, label: 'Rain', icon: CloudRain },
              { id: 'brownnoise' as const, label: 'Brown Noise', icon: Waves },
              { id: 'cafe' as const, label: 'Cafe', icon: Coffee },
            ].map((snd) => {
              const Icon = snd.icon;
              const isActive = currentSound === snd.id;
              return (
                <button
                  key={snd.id}
                  onClick={() => handleSoundToggle(snd.id)}
                  className={`flex-1 flex flex-col items-center justify-center p-2 rounded-xl border text-[10px] font-semibold transition ${
                    isActive
                      ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 mb-1" />
                  <span>{snd.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Rotating Motivational Quote */}
      <div className="text-center max-w-xl mx-auto py-2">
        <p className="text-xs text-slate-400 italic transition-all duration-700">
          {quotes[quoteIndex]}
        </p>
      </div>
    </div>
  );
};
